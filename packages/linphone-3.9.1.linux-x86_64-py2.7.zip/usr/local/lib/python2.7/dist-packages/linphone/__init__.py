from linphone import *
from linphone import __version__
